# node-mongo-api

NodeJS + MongoDB API for User Management, Authentication and Registration

## Load Initial Data
mongoimport --db issuetracker --collection issues --drop --file issues-data.json --jsonArray

## Load Initial Data
mongoimport --db smsDB --collection users --drop --file users-data.json --jsonArray

/* 1 */
{
    "_id" : ObjectId("5d663d8a213d5744fcf58798"),
    "role" : "user",
    "firstName" : "Hari",
    "lastName" : "Panakkal",
    "username" : "hari",
    "createdDate" : ISODate("2019-08-28T08:38:34.844Z"),
    "hash" : "$2a$10$4msYvItQyEUV2TG5U3BN9uVEJdRAxDwa8g/u3OkbIzzKVdlV0FbuG",
    "__v" : 0
}

/* 2 */
{
    "_id" : ObjectId("5d664b60213d5744fcf58799"),
    "role" : "user",
    "firstName" : "Madhu",
    "lastName" : "R",
    "username" : "madhu",
    "createdDate" : ISODate("2019-08-28T09:37:36.691Z"),
    "hash" : "$2a$10$qKqT0fsyWRr8QwgvZsRfXedeuepsg/Id0lZ1KHq4lpL8LCcZ6QY/m",
    "__v" : 0
}

/* 3 */
{
    "_id" : ObjectId("5d66947a182e6d9a5044669b"),
    "role" : "user",
    "firstName" : "Appu",
    "lastName" : "H",
    "username" : "appu",
    "createdDate" : ISODate("2019-08-28T14:49:30.224Z"),
    "hash" : "$2a$10$TlB9tB0B//tsxAbukBhRq.AkuW3h5avdC9vu4jgwpYFbRnh5ZgR0S",
    "__v" : 0
}

/* 4 */
{
    "_id" : ObjectId("5d6694af182e6d9a5044669c"),
    "role" : "user",
    "firstName" : "Aarav",
    "lastName" : "H",
    "username" : "aarav",
    "createdDate" : ISODate("2019-08-28T14:50:23.590Z"),
    "hash" : "$2a$10$yUVZvDzHWagXq7ZHxqiN7ePxmystH69/OvFgJc8RdA3n/2aRBCguW",
    "__v" : 0
}

/* 5 */
{
    "_id" : ObjectId("5d669ad2182e6d9a5044669d"),
    "role" : "admin",
    "firstName" : "Admin",
    "lastName" : "Admin",
    "username" : "admin",
    "createdDate" : ISODate("2019-08-28T15:16:34.488Z"),
    "hash" : "$2a$10$lN6ZZq/HK694u6GH16Q4vuSsQNaGi7nZ.1bKuJ.cUX42.W9A9FPQO",
    "__v" : 0
}

/* 6 */
{
    "_id" : ObjectId("5d836d5c13c8bd5db432147b"),
    "role" : "user",
    "firstName" : "newuserFName",
    "lastName" : "newuserLName",
    "username" : "newuser",
    "createdDate" : ISODate("2019-09-19T11:58:20.214Z"),
    "hash" : "$2a$10$yveDZEK90U5DcQzjyGWOBe1NSMkJmF7ENYiX7JMrzn.MD7zhJsxca",
    "__v" : 0
}


-- insert

[
    {
    "_id" : ObjectId("5d663d8a213d5744fcf58798"),
    "role" : "user",
    "firstName" : "Hari",
    "lastName" : "Panakkal",
    "username" : "hari",
    "createdDate" : ISODate("2019-08-28T08:38:34.844Z"),
    "hash" : "$2a$10$4msYvItQyEUV2TG5U3BN9uVEJdRAxDwa8g/u3OkbIzzKVdlV0FbuG",
    "__v" : 0
},
{
    "_id" : ObjectId("5d664b60213d5744fcf58799"),
    "role" : "user",
    "firstName" : "Madhu",
    "lastName" : "R",
    "username" : "madhu",
    "createdDate" : ISODate("2019-08-28T09:37:36.691Z"),
    "hash" : "$2a$10$qKqT0fsyWRr8QwgvZsRfXedeuepsg/Id0lZ1KHq4lpL8LCcZ6QY/m",
    "__v" : 0
},
{
    "_id" : ObjectId("5d66947a182e6d9a5044669b"),
    "role" : "user",
    "firstName" : "Appu",
    "lastName" : "H",
    "username" : "appu",
    "createdDate" : ISODate("2019-08-28T14:49:30.224Z"),
    "hash" : "$2a$10$TlB9tB0B//tsxAbukBhRq.AkuW3h5avdC9vu4jgwpYFbRnh5ZgR0S",
    "__v" : 0
},
{
    "_id" : ObjectId("5d6694af182e6d9a5044669c"),
    "role" : "user",
    "firstName" : "Aarav",
    "lastName" : "H",
    "username" : "aarav",
    "createdDate" : ISODate("2019-08-28T14:50:23.590Z"),
    "hash" : "$2a$10$yUVZvDzHWagXq7ZHxqiN7ePxmystH69/OvFgJc8RdA3n/2aRBCguW",
    "__v" : 0
},
{
    "_id" : ObjectId("5d669ad2182e6d9a5044669d"),
    "role" : "admin",
    "firstName" : "Admin",
    "lastName" : "Admin",
    "username" : "admin",
    "createdDate" : ISODate("2019-08-28T15:16:34.488Z"),
    "hash" : "$2a$10$lN6ZZq/HK694u6GH16Q4vuSsQNaGi7nZ.1bKuJ.cUX42.W9A9FPQO",
    "__v" : 0
},
{
    "_id" : ObjectId("5d836d5c13c8bd5db432147b"),
    "role" : "user",
    "firstName" : "newuserFName",
    "lastName" : "newuserLName",
    "username" : "newuser",
    "createdDate" : ISODate("2019-09-19T11:58:20.214Z"),
    "hash" : "$2a$10$yveDZEK90U5DcQzjyGWOBe1NSMkJmF7ENYiX7JMrzn.MD7zhJsxca",
    "__v" : 0
}
]


