## Load Initial User Data
mongoimport --db smsDB --collection users --drop --file users-data.json --jsonArray


mongoimport --host Cluster0-shard-0/cluster0-shard-00-00-qok4o.gcp.mongodb.net:27017,cluster0-shard-00-01-qok4o.gcp.mongodb.net:27017,cluster0-shard-00-02-qok4o.gcp.mongodb.net:27017 --ssl --username smsUser --password smsPassword --authenticationDatabase admin --db smsDB --collection users --type <FILETYPE> --file <FILENAME>

mongoimport --host Cluster0-shard-0/cluster0-shard-00-00-qok4o.gcp.mongodb.net:27017,cluster0-shard-00-01-qok4o.gcp.mongodb.net:27017,cluster0-shard-00-02-qok4o.gcp.mongodb.net:27017 --ssl --username smsUser --password smsPassword --authenticationDatabase admin --db smsDB --collection users --drop --file users-data.json --jsonArray